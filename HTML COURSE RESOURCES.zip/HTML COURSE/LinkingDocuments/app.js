 var Name = 20+20;
 document.write(Name);
 